//
//  TableViewCell.swift
//  NewProject1
//
//  Created by sravan yadav on 28/04/24.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var arrow: UILabel!
    @IBOutlet var passwordLabel: UILabel!
    @IBOutlet var googleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        contentView.layer.cornerRadius = 10
               contentView.clipsToBounds = true
        // Configure the view for the selected state
    }
    
}
