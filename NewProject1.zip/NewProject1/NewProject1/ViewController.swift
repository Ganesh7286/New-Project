//
//  ViewController.swift
//  NewProject1
//
//  Created by sravan yadav on 28/04/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var accountArray = [String]()
    var emailArray = [String]()
    var passwordArray = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup your table view
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) // Adjust separator inset
        
        // Load saved data from UserDefaults
       loadDataFromUserDefaults()
    }

    @IBAction func addButtonTapped(_ sender: UIButton) {
        // Show the popup view
        showPopup()
    }

    func showPopup() {
        let popupView = UIView(frame: CGRect(x: 0, y: view.frame.height, width: view.frame.width, height: 200))
        popupView.backgroundColor = .white
        
        let textFieldHeight: CGFloat = 30
        let textFieldSpacing: CGFloat = 10
        
        let textField1 = UITextField(frame: CGRect(x: 20, y: 20, width: popupView.frame.width - 40, height: textFieldHeight))
        textField1.placeholder = "Account Name"
        textField1.layer.cornerRadius = 8
        textField1.layer.borderWidth = 1
        textField1.layer.borderColor = UIColor.lightGray.cgColor
        popupView.addSubview(textField1)
        
        let textField2 = UITextField(frame: CGRect(x: 20, y: textField1.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: textFieldHeight))
        textField2.placeholder = "Email"
        textField2.layer.cornerRadius = 8
        textField2.layer.borderWidth = 1
        textField2.layer.borderColor = UIColor.lightGray.cgColor
        popupView.addSubview(textField2)
        
        let textField3 = UITextField(frame: CGRect(x: 20, y: textField2.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: textFieldHeight))
        textField3.placeholder = "Password"
        textField3.layer.cornerRadius = 8
        textField3.layer.borderWidth = 1
        textField3.layer.borderColor = UIColor.lightGray.cgColor
        textField3.isSecureTextEntry = true
        popupView.addSubview(textField3)
        
        // Now, configure the eye button for password visibility toggle
        let eyeButton = UIButton(type: .custom)
        eyeButton.setImage(UIImage(named: "eye_open"), for: .normal)
        eyeButton.frame = CGRect(x: textField3.frame.width - 25, y: 5, width: 20, height: 20)
        eyeButton.addTarget(self, action: #selector(togglePasswordVisibility(_:)), for: .touchUpInside)
        textField3.rightView = eyeButton
        textField3.rightViewMode = .always

        let addButton = UIButton(frame: CGRect(x: 20, y: textField3.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: 30))
        addButton.setTitle("Add", for: .normal)
        addButton.backgroundColor = .blue
        addButton.layer.cornerRadius = 8
        addButton.addTarget(self, action: #selector(addData(_:)), for: .touchUpInside)
        popupView.addSubview(addButton)
        
        view.addSubview(popupView)
        
        UIView.animate(withDuration: 0.3) {
            popupView.frame.origin.y = self.view.frame.height - popupView.frame.height
        }
    }

    @objc func addData(_ sender: UIButton) {
        guard let textField1 = view.subviews.last?.subviews.compactMap({ $0 as? UITextField }).first,
              let textField2 = textField1.superview?.subviews[1] as? UITextField,
              let textField3 = textField2.superview?.subviews[2] as? UITextField else {
            return
        }

        // Check if any text field is empty
        guard let account = textField1.text, !account.isEmpty,
              let email = textField2.text, !email.isEmpty,
              let password = textField3.text, !password.isEmpty else {
            showAlert(message: "All fields are required.")
            return
        }

        // Validate password strength
        if !isPasswordStrong(password) {
            showAlert(message: "Password should contain at least 8 characters with a mix of letters, numbers, and special characters.")
            return
        }

        // Add the entered data to your arrays
        accountArray.append(account)
        emailArray.append(email)
        passwordArray.append(password)

        // Save data to UserDefaults
        saveDataToUserDefaults()
        
        // Reload your table view
        tableView.reloadData()

        // Close the popup
        dismissPopup()
    }

    func dismissPopup() {
        if let popupView = view.subviews.last {
            UIView.animate(withDuration: 0.3, animations: {
                popupView.frame.origin.y = self.view.frame.height
            }) { (_) in
                popupView.removeFromSuperview()
            }
        }
    }
    
    @objc func editData(_ sender: UIButton) {
        let index = sender.tag
        // Check if the index is valid
        guard index < accountArray.count,
              index < emailArray.count,
              index < passwordArray.count else {
            return
        }

        // Get the existing data for the selected row
        let account = accountArray[index]
        let email = emailArray[index]
        let password = passwordArray[index]

        // Show the popup for editing
        showEditPopup(account: account, email: email, password: password, atIndex: index)
    }
    func showEditPopup(account: String, email: String, password: String, atIndex index: Int) {
           let popupView = UIView(frame: CGRect(x: 0, y: view.frame.height, width: view.frame.width, height: 400))
           popupView.backgroundColor = .white
           
           let textFieldHeight: CGFloat = 30
           let textFieldSpacing: CGFloat = 10
           
           // Label for Accountant
           let accountantLabel = UILabel(frame: CGRect(x: 20, y: 20, width: popupView.frame.width - 40, height: 30))
           accountantLabel.text = "Account Details"
           popupView.addSubview(accountantLabel)
           
           // Text Field 1 (Accountant)
           let textField1 = UITextField(frame: CGRect(x: 20, y: accountantLabel.frame.maxY + 5, width: popupView.frame.width - 40, height: textFieldHeight))
           textField1.placeholder = "Enter Account"
           textField1.text = account
           textField1.layer.cornerRadius = 8
           textField1.layer.borderWidth = 1
           textField1.layer.borderColor = UIColor.lightGray.cgColor
           popupView.addSubview(textField1)
           
           // Label for Email
           let emailLabel = UILabel(frame: CGRect(x: 20, y: textField1.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: 30))
           emailLabel.text = "Email:"
           popupView.addSubview(emailLabel)
           
           // Text Field 2 (Email)
           let textField2 = UITextField(frame: CGRect(x: 20, y: emailLabel.frame.maxY + 5, width: popupView.frame.width - 40, height: textFieldHeight))
           textField2.placeholder = "Enter Email"
           textField2.text = email
           textField2.layer.cornerRadius = 8
           textField2.layer.borderWidth = 1
           textField2.layer.borderColor = UIColor.lightGray.cgColor
           popupView.addSubview(textField2)
           
           // Label for Password
           let passwordLabel = UILabel(frame: CGRect(x: 20, y: textField2.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: 30))
           passwordLabel.text = "Password:"
           popupView.addSubview(passwordLabel)
           
           // Text Field 3 (Password)
           let textField3 = UITextField(frame: CGRect(x: 20, y: passwordLabel.frame.maxY + 5, width: popupView.frame.width - 40, height: textFieldHeight))
           textField3.placeholder = "Enter Password"
           textField3.text = password
           textField3.layer.cornerRadius = 8
           textField3.layer.borderWidth = 1
           textField3.layer.borderColor = UIColor.lightGray.cgColor
           popupView.addSubview(textField3)
           
           let eyeButton = UIButton(type: .custom)
           eyeButton.setImage(UIImage(named: "eye_open"), for: .normal)
           eyeButton.frame = CGRect(x: textField3.frame.width - 25, y: 5, width: 20, height: 20)
           eyeButton.addTarget(self, action: #selector(togglePasswordVisibility(_:)), for: .touchUpInside)
           textField3.rightView = eyeButton
           textField3.rightViewMode = .always
           
           let editButton = UIButton(frame: CGRect(x: 20, y: textField3.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: 30))
           editButton.setTitle("Edit", for: .normal)
           editButton.backgroundColor = .blue
           editButton.layer.cornerRadius = 8
           editButton.addTarget(self, action: #selector(updateData(_:)), for: .touchUpInside)
           editButton.tag = index // Set tag to identify which row is being edited
           popupView.addSubview(editButton)
           
           let deleteButton = UIButton(frame: CGRect(x: 20, y: editButton.frame.maxY + textFieldSpacing, width: popupView.frame.width - 40, height: 30))
           deleteButton.setTitle("Delete", for: .normal)
           deleteButton.backgroundColor = .red
           deleteButton.layer.cornerRadius = 8
           deleteButton.addTarget(self, action: #selector(deleteData(_:)), for: .touchUpInside)
           deleteButton.tag = index // Set tag to identify which row is being deleted
           popupView.addSubview(deleteButton)

           view.addSubview(popupView)
           
           UIView.animate(withDuration: 0.3) {
               popupView.frame.origin.y = self.view.frame.height - popupView.frame.height
           }
       }


    @objc func updateData(_ sender: UIButton) {
        let index = sender.tag
        // Check if the index is valid
        guard index < accountArray.count,
              index < emailArray.count,
              index < passwordArray.count else {
            return
        }

        // Get the text field values
        guard let textField1 = (view.subviews.last?.subviews.compactMap { $0 as? UITextField })?[0],
              let textField2 = (view.subviews.last?.subviews.compactMap { $0 as? UITextField })?[1],
              let textField3 = (view.subviews.last?.subviews.compactMap { $0 as? UITextField })?[2] else {
            return
        }

        // Check if any text field is empty
        guard let account = textField1.text, !account.isEmpty,
              let email = textField2.text, !email.isEmpty,
              let password = textField3.text, !password.isEmpty else {
            showAlert(message: "All fields are required.")
            return
        }

        // Validate password strength
        if !isPasswordStrong(password) {
            showAlert(message: "Password should contain at least 8 characters with a mix of letters, numbers, and special characters.")
            return
        }

        // Update the data at the specified index
        accountArray[index] = account
        emailArray[index] = email
        passwordArray[index] = password

        // Save updated data to UserDefaults
        saveDataToUserDefaults()

        // Reload your table view
        tableView.reloadData()

        // Dismiss the popup
        dismissPopup()
    }
    
    @objc func deleteData(_ sender: UIButton) {
        let index = sender.tag
        // Check if the index is valid
        guard index < accountArray.count,
              index < emailArray.count,
              index < passwordArray.count else {
            return
        }

        // Remove data at the specified index
        accountArray.remove(at: index)
        emailArray.remove(at: index)
        passwordArray.remove(at: index)

        // Save updated data to UserDefaults
        saveDataToUserDefaults()

        // Reload your table view
        tableView.reloadData()

        // Dismiss the popup
        dismissPopup()
    }

    func saveDataToUserDefaults() {
        UserDefaults.standard.set(accountArray, forKey: "AccountArray")
        UserDefaults.standard.set(emailArray, forKey: "EmailArray")
        UserDefaults.standard.set(passwordArray, forKey: "PasswordArray")

        // Synchronize UserDefaults to reflect the changes immediately
        UserDefaults.standard.synchronize()
    }


  

    
    @objc func togglePasswordVisibility(_ sender: UIButton) {
        // Get the parent view of the sender button
        guard let textField = sender.superview as? UITextField else { return }
        
        // Toggle password visibility
        textField.isSecureTextEntry.toggle()
        
        // Change eye button image based on password visibility
        let imageName = textField.isSecureTextEntry ? "eye_closed" : "eye_open"
        sender.setImage(UIImage(named: imageName), for: .normal)
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }

    func isPasswordStrong(_ password: String) -> Bool {
        // Password strength criteria: at least 8 characters with a mix of letters, numbers, and special characters
        let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$"
        let passwordPredicate = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        return passwordPredicate.evaluate(with: password)
    }
    
    // Function to save all data to UserDefaults
  
    
    // Function to load all data from UserDefaults
    func loadDataFromUserDefaults() {
        if let savedAccountArray = UserDefaults.standard.array(forKey: "AccountArray") as? [String],
           let savedEmailArray = UserDefaults.standard.array(forKey: "EmailArray") as? [String],
           let savedPasswordArray = UserDefaults.standard.array(forKey: "PasswordArray") as? [String] {
            accountArray = savedAccountArray
            emailArray = savedEmailArray
            passwordArray = savedPasswordArray
            tableView.reloadData()
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return accountArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        
        // Check if indexPath.row is within the bounds of accountArray and passwordArray
        guard indexPath.row < accountArray.count,
              indexPath.row < passwordArray.count else {
            // If index is out of range, display a placeholder or handle it as appropriate
            cell.googleLabel.text = "Account not available"
            cell.passwordLabel.text = "Password not available"
            cell.selectionStyle = .none
            return cell
        }
        
        // Set cell data
        cell.googleLabel.text = accountArray[indexPath.row]
        
        // Masked password display
        let passwordLength = passwordArray[indexPath.row].count
        let maskedPassword = String(repeating: "*", count: passwordLength)
        cell.passwordLabel.text = maskedPassword
        
        cell.selectionStyle = .none
        return cell
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Check if indexPath.row is within the bounds of all arrays
        guard indexPath.row < accountArray.count,
              indexPath.row < emailArray.count,
              indexPath.row < passwordArray.count else {
            // If index is out of range, handle it as appropriate (e.g., show an error message)
            print("Index out of range")
            return
        }
        
        // Access elements from arrays
        let account = accountArray[indexPath.row]
        let email = emailArray[indexPath.row]
        let password = passwordArray[indexPath.row]
        
        // Show edit popup with the selected data
        showEditPopup(account: account, email: email, password: password, atIndex: indexPath.row)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
}

